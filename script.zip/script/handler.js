const fs = require('fs');
const path = require('path');
const url = require('url');
const Config = require('./config.js');
const plugins = require('./System/plugins.js');

class Handler {
  constructor() {
    this.plugins = {};
    this.commands = {};
    this.categories = {};
    this.__dirname = path.join(path.dirname(url.fileURLToPath(import.meta.url)), './Plugins');
  }

  async handlePlugins() {
    for (const name in plugins) {
      let plugin = plugins[name];
      if (!plugin) continue;

      const __filename = path.join(this.__dirname, name);
      if (typeof plugin.all === 'function') {
        try {
          await plugin.all.call(this, m, { chatUpdate, __dirname: this.__dirname, __filename });
        } catch (e) {
          console.error(e);
          // ...
        }
      }
    }
  }

  handleCommand(socket, message, command, args) {
    if (this.commands[command]) {
      this.commands[command](socket, message, args);
    } else {
      socket.sendMessage(message.key.remoteJid, { text: `Command tidak ditemukan!` });
    }
  }

  addCommand(plugin) {
    if (!this.categories[plugin.category]) {
      this.categories[plugin.category] = [];
    }
    this.categories[plugin.category].push(plugin);
    plugin.usage.forEach((cmd) => {
      this.commands[cmd] = plugin.use;
    });
  }

  removeCommand(command) {
    delete this.commands[command];
  }

  getCommands(category) {
    return this.categories[category];
  }
}

module.exports = Handler;