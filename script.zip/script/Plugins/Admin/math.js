module.exports = {
  name: 'Math',
  category: 'Tools',
  usage: ['tambah', 'kurang'],
  hidden: ['admin'],
  use: (socket, message, args) => {
    const num1 = parseInt(args[0]);
        const num2 = parseInt(args[1]);
        const result = num1 + num2;
        socket.sendMessage(message.key.remoteJid, { text: `Hasil: ${result}` });
      },
      hidden: false
    },
    {
      command: 'kurang',
      callback: (socket, message, args) => {
        const num1 = parseInt(args[0]);
        const num2 = parseInt(args[1]);
        const result = num1 - num2;
        socket.sendMessage(message.key.remoteJid, { text: `Hasil: ${result}` });
      },
      hidden: false
    },
    {
      command: 'admin',
      callback: (socket, message, args) => {
        socket.sendMessage(message.key.remoteJid, { text: `Halo Admin!` });
      },
      hidden: true
    }
  ]
};