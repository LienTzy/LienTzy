module.exports = {
  name: 'ping',
  description: 'Cek latency bot',
  execute: async (message, args, client) => {
    const startTime = Date.now();
    client.sendMessage(message.chat, 'Pong!');
    const endTime = Date.now();
    const latency = endTime - startTime;
    client.sendMessage(message.chat, `Latency: ${latency}ms`);
  },
  usage: [''],
  hidden: [''],
  use: 'Cek latency bot',
  category: 'Tools'
};
