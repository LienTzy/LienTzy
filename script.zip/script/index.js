console.log('Mulai...');

const path = require('path');
const cluster = require('cluster');
const fs = require('fs');
const cfonts = require('cfonts');
const readline = require('readline');
const yargs = require('yargs');
const chalk = require('chalk');
const os = require('os');
const Config = require('./config.js');

const rl = readline.createInterface(process.stdin, process.stdout);

cfonts.say('ItzMe Bagz', {
  font: 'grid',
  align: 'center',
  colors: ['cyan', '#f00'],
  gradient: false
});

cfonts.say(`Bot WhatsApp\nDibuat oleh @ItzMeRzll`, {
  font: 'console',
  align: 'center',
  gradient: ['red', 'magenta']
});

let isRunning = false;

function start(file) {
  if (isRunning) return;
  isRunning = true;

  const currentFilePath = __dirname;
  const args = [path.join(__dirname, file), ...process.argv.slice(2)];

  cfonts.say([process.argv[0], ...args].join(' '), {
    font: 'console',
    align: 'center',
    gradient: ['red', 'white']
  });

  cluster.setupMaster({
    exec: args[0],
    args: args.slice(1)
  });

  const p = cluster.fork();

  p.on('message', data => {
    console.log('[ DITERIMA ]', data);
    switch (data) {
      case 'reset':
        p.process.kill();
        isRunning = false;
        start.apply(this, arguments);
        break;
      case 'uptime':
        p.send(process.uptime());
        break;
    }
  });

  p.on('exit', code => {
    isRunning = false;
    console.error('Keluar dengan kode:', code);
    start('main.js');
  });

  const ramInGB = os.totalmem() / (1024 * 1024 * 1024);
  const freeRamInGB = os.freemem() / (1024 * 1024 * 1024);

  console.log(chalk.yellow(` ${os.type()}, ${os.release()} - ${os.arch()}`));
  console.log(chalk.yellow(` Total RAM: ${ramInGB.toFixed(2)} GB`));
  console.log(chalk.yellow(` Free RAM: ${freeRamInGB.toFixed(2)} GB`));
  console.log(chalk.yellow(` Script oleh @itzmebgz`));

  console.log(chalk.blue.bold(`\n Informasi Lain`));
  console.log(`Nama: ${chalk.cyan('Bot - MD')}`);
  console.log(`Versi: ${chalk.cyan(Config.version)}`);
  console.log(`Deskripsi: ${chalk.cyan('Bot WhatsApp Pribadi')}`);
  console.log(`Pembuat: ${chalk.cyan('Dibuat oleh @ItzMeRzl')}`);

  console.log(chalk.blue.bold(`\n Zona Waktu`));
  const currentTime = new Date().toLocaleString('es-ES', {
    timeZone: 'Asia/Jakarta'
  });
  console.log(chalk.cyan(`${currentTime}`));

  setInterval(() => {}, 1000);

  let opts = yargs(process.argv.slice(2)).exitProcess(false).parse();
  if (!opts['test']) {
    if (!rl.listenerCount()) {
      rl.on('line', line => {
        p.emit('message', line.trim());
      });
    }
  }
}

start('client.js');