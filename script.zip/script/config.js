module.exports = {
  // Pengaturan Umum
  name: 'Bot WhatsApp',
  version: '1.0.0',
  description: 'Bot WhatsApp pribadi',
  owner: 'ItzMeRzll',

  // Pengaturan WhatsApp
  phoneNumber: '+6281234567890',
  clientID: 'client-id',
  clientSecret: 'client-secret',

  // Pengaturan Server
  port: 3000,
  host: 'localhost',

  // Pengaturan Database
  db: {
    type: 'json',
    file: 'database.json'
  },

  // Pengaturan Plugin
  plugins: {
    enabled: ['math', 'welcome'],
    disabled: []
  },

  // Pengaturan Lain
  prefix: '.',
  color: 'cyan',
  debug: true
};
