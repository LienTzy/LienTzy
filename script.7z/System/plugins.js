const fs = require('fs');
const path = require('path');
const os = require('os');
const syntaxError = require('syntax-error');

const pluginFolder = './Plugins';
const pluginFilter = filename => /\.(mc|c)?js$/.test(filename);

let watcher = {},
  plugins = {},
  pluginFolders = [];

async function loadPluginFiles(plugFolder = pluginFolder, plugFilter = pluginFilter, opts = { recursiveRead: false }) {
  const folder = path.resolve(plugFolder);
  if (folder in watcher) return;

  pluginFolders.push(folder);
  const paths = await fs.promises.readdir(plugFolder);
  await Promise.all(paths.map(async path => {
    const resolved = path.join(folder, path);
    const dirname = path.dirname(resolved);
    const formatedFilename = formatFilename(resolved);

    try {
      const stats = await fs.promises.lstat(resolved);
      if (!stats.isFile()) {
        if (opts.recursiveRead) await loadPluginFiles(resolved, plugFilter, opts);
        return;
      }

      const filename = path.basename(resolved);
      const isValidFile = plugFilter(filename);
      if (!isValidFile) return;

      const module = await import(resolved);
      if (module) plugins[formatedFilename] = module;
    } catch (e) {
      opts.logger?.error(e, `error while requiring ${formatedFilename}`);
      delete plugins[formatedFilename];
    }
  }));

  const watching = fs.watch(folder, reload.bind(null, { logger: opts.logger, plugFolder, plugFilter }));
  watching.on('close', () => deletePluginFolder(folder, true));
  watcher[folder] = watching;

  return plugins = sortedPlugins(plugins);
}

function deletePluginFolder(folder, isAlreadyClosed = false) {
  const resolved = path.resolve(folder);
  if (!(resolved in watcher)) return;

  if (!isAlreadyClosed) watcher[resolved].close();
  delete watcher[resolved];
  pluginFolders.splice(pluginFolders.indexOf(resolved), 1);
}

async function reload({ logger, plugFolder = pluginFolder, plugFilter = pluginFilter }, _ev, filename) {
  if (plugFilter(filename)) {
    const file = path.join(plugFolder, filename);
    const formatedFilename = formatFilename(file);

    if (formatedFilename in plugins) {
      if (fs.existsSync(file)) {
        logger?.info(`updated plugin - '${formatedFilename}'`);
      } else {
        logger?.warn(`deleted plugin - '${formatedFilename}'`);
        return delete plugins[formatedFilename];
      }
    } else logger?.info(`new plugin - '${formatedFilename}'`);

    const src = await fs.promises.readFile(file);
    let err = syntaxError(src, filename, { sourceType: 'module', allowAwaitOutsideFunction: true });
    if (err) {
      logger?.error(err, `syntax error while loading '${formatedFilename}'`);
    } else try {
      const module = await import(file);
      if (module) plugins[formatedFilename] = module;
    } catch (e) {
      logger?.error(e, `error require plugin '${formatedFilename}'`);
      delete plugins[formatedFilename];
    } finally {
      plugins = sortedPlugins(plugins);
    }
  }
}

function formatFilename(filename) {
  const dir = path.join(__dirname, '../');
  const regex = new RegExp(`^${dir}`);
  return filename.replace(regex, '');
}

function sortedPlugins(plugins) {
  return Object.fromEntries(Object.entries(plugins).sort(([a], [b]) => a.localeCompare(b)));
}

module.exports = {
  pluginFolder,
  pluginFilter,
  plugins,
  watcher,
  pluginFolders,
  loadPluginFiles,
  deletePluginFolder,
  reload,
};
