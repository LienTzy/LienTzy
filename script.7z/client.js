const express = require('express');
const helmet = require('helmet');
const bodyParser = require('body-parser');
const cors = require('cors');
const { default: makeWASocket,
  Browsers,
  DisconnectReason,
  fetchLatestBaileysVersion,
  jidNormalizedUser,
  makeCacheableSignalKeyStore,
  PHONENUMBER_MCC,
  proto,
  useMultiFileAuthState,
 } = require('@whiskeysockets/baileys');
const pino = require('pino');
const fs = require('fs-extra');
const readline = require('readline');
const path = require('path');
const mime = require('mime');
const chalk = require('chalk');
const figlet = require('figlet');
const Handler = require('./handler.js');
const Config = require('./config.js');
const nodeFetch = require('node-fetch');

const session = 'auth';
const pairingCode = true;

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

const question = (text) => {
  return new Promise((resolve) => rl.question(text, resolve));
};

const handler = new Handler();
handler.loadPlugins();

const app = express();
app.use(helmet());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cors());

app.listen(3000, () => {
  console.log('Server berjalan di port 3000');
});

async function start() {
  const { state, saveCreds } = await useMultiFileAuthState(session);
  const socket = WaPairing({
    printQRInTerminal: !pairingCode,
    logger: pino({ level: 'silent' }),
    browser: ['Chrome (Linux)', '', ''],
    auth: state,
  });

  socket.ev.on('connection.update', async ({ connection, lastDisconnect }) => {
    if (connection === 'open') {
      console.log('Berhasil Terhubung Ke WhatsApp!');
    } else if (connection === 'close' && lastDisconnect.error) {
      console.log('Koneksi tertutup. Mencoba menghubungkan kembali...');
      await start();
    }
  });

  socket.ev.on('creds.update', async ({ creds }) => {
    if (!creds.registered) {
      console.log('Akun belum terdaftar. Silakan daftar terlebih dahulu.');
      await start();
    }
    saveCreds();
  });

  socket.ev.on('messages.upsert', async ({ messages }) => {
    const m = messages[0];
    const msgText = m.message.conversation;
    const command = msgText.trim().split(/ +/).shift().toLowerCase();

    if (!msgText.startsWith('.')) return;

    await handler.handleCommand(socket, m, command, msgText);

    // Pengiriman file
    if (m.message.file) {
      await socket.sendMessage(m.key.remoteJid, { file: m.message.file });
    }

    // Pengiriman lokasi
    if (m.message.location) {
      await socket.sendMessage(m.key.remoteJid, { location: m.message.location });
    }

    // Pengiriman kontak
    if (m.message.contact) {
      await socket.sendMessage(m.key.remoteJid, { contact: m.message.contact });
    }

    // Pengiriman teks dengan mention
    if (msgText.startsWith('.')) {
      const mention = msgText.split(' ')[1];
      await socket.sendMessage(m.key.remoteJid, { text: `Mention: @${mention}`, mentions: [mention] });
    }
  });

  if (pairingCode && !socket.authState.creds.registered) {
    const phoneNumber = await question('Masukan Nomer Telepon: ');
    const code = await socket.requestPairingCode(phoneNumber);
    console.log('Code Pairing Anda: \n' + code);
  }
}

async function reload(conn, restartConnection, opts = { store: null, logger: null, authState: null }) {
  if (!opts.handler) {
    opts.handler = require('./handler.js');
  }

  const isReloadInit = !!conn.isReloadInit;

  if (restartConnection) {
    try {
      conn.ws.close();
    } catch {}
    conn.ev.removeAllListeners();
    Object.assign(conn, await start(conn, opts) || {});
  }

  Object.assign(conn, getMessageConfig());

  if (!isReloadInit) {
    if (conn.handler) conn.ev.off('messages.upsert', conn.handler);
    if (conn.participantsUpdate) conn.ev.off('group-participants.update', conn.participantsUpdate);
    if (conn.groupsUpdate) conn.ev.off('groups.update', conn.groupsUpdate);
    if (conn.onDelete) conn.ev.off('messages.delete', conn.onDelete);
    if (conn.connectionUpdate) conn.ev.off('connection.update', conn.connectionUpdate);
    if (conn.credsUpdate) conn.ev.off('creds.update', conn.credsUpdate);
  }

  if (opts.handler) {
    conn.handler = opts.handler.handler.bind(conn);
    conn.participantsUpdate = opts.handler.participantsUpdate.bind(conn);
    conn.groupsUpdate = opts.handler.groupsUpdate.bind(conn);
    conn.onDelete = opts.handler.deleteUpdate.bind(conn);
  }

  if (!opts.isChild) {
    conn.connectionUpdate = connectionUpdate.bind(conn, opts);
  }

  conn.credsUpdate = opts.authState.saveCreds.bind(conn);

  conn.ev.on('messages.upsert', conn.handler);
  conn.ev.on('group-participants.update', conn.participantsUpdate);
  conn.ev.on('groups.update', conn.groupsUpdate);
  conn.ev.on('messages.delete', conn.onDelete);
  if (!opts.isChild) {
    conn.ev.on('connection.update', conn.connectionUpdate);
  }
  conn.ev.on('creds.update', conn.credsUpdate);

  conn.isReloadInit = false;
  return true;
}

async function connectionUpdate(opts, update) {
  const { connection, lastDisconnect, isNewLogin } = update;
  if (isNewLogin) {
    this.isInit = true;
  }
  const code = lastDisconnect?.error?.output?.statusCode || lastDisconnect?.error?.output?.payload?.statusCode;
  if (connection == 'close' && code != DisconnectReason.loggedOut) {
    console.log('- Connection Closed, Reconnecting -');
    await reload(this, true, opts).catch(console.error);
    global.timestamp.connect = new Date;
  }
  if (connection == 'open') {
    console.log('- Opened Connection -');
    await this.sendMessage(Config.owner_jid, { text: `Bot is online âœ“\n\n*Client*: @${this.user?.jid.split('@')[0]}`, mentions: [this.user?.jid] });
  }
  if (db.data == null) {
    loadDatabase();
  }
}

function getMessageConfig() {
  const welcome = 'Ciao @user! ðŸ‘‹\n\nWelcome to\n*@subject*\n\nJangan lupa baca deskripsi grup ya ðŸ¤—\n\n> @info';
  const bye = 'Adiós amigo @user! ðŸ‘‹\n\n> @info';
  const spromote = '@user sekarang admin!';
  const sdemote = '@user sekarang bukan admin!';
  const sDesc = 'Deskripsi telah diubah ke\n\n@desc';
  const sSubject = 'Subject grup telah diubah ke\n\n@subject';
  const sIcon = 'Icon grup telah diubah!';
  const sRevoke = 'Link group telah diubah ke\n\n@revoke';
  return { welcome, bye, spromote, sdemote, sDesc, sSubject, sIcon, sRevoke };
}

const conn = start(null, { store, logger, authState }).catch(console.error);

module.exports = {
  start,
  reload,
  conn,
  conns: null,
  logger: null,
  connectionOptions: null,
  authFolder: null,
  storeFile: null,
  authState: null,
  store: null,
  getMessageConfig,
};
